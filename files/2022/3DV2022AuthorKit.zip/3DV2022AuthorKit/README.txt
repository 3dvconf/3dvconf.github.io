To make a sample 3DV submission, copy the contents of this directory
somewhere, and type

 latex egpaper_for_review

or 

 pdflatex egpaper_for_review


To make a final copy of the paper uncomment the line
\threedvfinalcopy 
at the beginning of the file or use the template egpaper_final.tex 
with the commands above.

Note that in some environments, it may be necessary to run bibtex 
explicitly (bibtex egpaper_final).
